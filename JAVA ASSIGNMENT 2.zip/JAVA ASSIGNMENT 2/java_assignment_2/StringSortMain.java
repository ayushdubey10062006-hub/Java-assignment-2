import java.util.ArrayList;
import java.util.Collections;

public class StringSortMain {

    public static void main(String[] args) {

        ArrayList<String> names = new ArrayList<>();

        names.add("Apple");
        names.add("Mango");
        names.add("Banana");
        names.add("Orange");

        System.out.println("Original List: " + names);

        Collections.sort(names, (a, b) -> b.compareTo(a));

        System.out.println("Descending Order: " + names);
    }
}