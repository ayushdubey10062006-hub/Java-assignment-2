import java.util.Scanner;

public class FactorialMain {

    public static long factorial(int n) throws Exception {

        if (n < 0) {
            throw new Exception("Number cannot be negative.");
        }

        long fact = 1;

        for (int i = 1; i <= n; i++) {
            fact = fact * i;
        }

        return fact;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = sc.nextInt();

        try {
            long result = factorial(number);
            System.out.println("Factorial = " + result);
        }
        catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }

        sc.close();
    }
}