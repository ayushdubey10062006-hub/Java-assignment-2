import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

class InvalidAgeException extends Exception {

    public InvalidAgeException(String message) {
        super(message);
    }
}

public class AgeLoggingMain {

    private static final Logger logger =
            Logger.getLogger(AgeLoggingMain.class.getName());

    public static void checkAge(int age) throws InvalidAgeException {

        if (age < 18) {
            throw new InvalidAgeException("Age is less than 18.");
        }

        System.out.println("You are eligible.");
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try {
            FileHandler fileHandler = new FileHandler("error.log");
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);

            System.out.print("Enter your age: ");
            int age = sc.nextInt();

            try {
                checkAge(age);
            }
            catch (InvalidAgeException e) {
                System.out.println("Exception: " + e.getMessage());
                logger.severe(e.getMessage());
            }

            fileHandler.close();

        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        sc.close();
    }
}