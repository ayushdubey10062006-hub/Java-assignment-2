import java.util.Scanner;
import java.util.function.Function;

public class SquareMain {

    public static int square(int n) {
        return n * n;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = sc.nextInt();

        Function<Integer, Integer> result = SquareMain::square;

        System.out.println("Square = " + result.apply(number));

        sc.close();
    }
}