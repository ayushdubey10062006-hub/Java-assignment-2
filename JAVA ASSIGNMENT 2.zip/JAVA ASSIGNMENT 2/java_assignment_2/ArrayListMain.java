import java.util.ArrayList;

public class ArrayListMain {

    public static void main(String[] args) {

        ArrayList<Integer> numbers = new ArrayList<>();

        numbers.add(10);
        numbers.add(20);
        numbers.add(30);
        numbers.add(40);
        numbers.add(50);

        System.out.println("Integers in the ArrayList:");

        for (int number : numbers) {
            System.out.println(number);
        }
    }
}