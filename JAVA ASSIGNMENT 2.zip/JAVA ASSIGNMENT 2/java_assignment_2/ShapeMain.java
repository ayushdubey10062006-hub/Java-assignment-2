import shapes.Circle;
import shapes.Rectangle;

public class ShapeMain {

    public static void main(String[] args) {

        Circle circle = new Circle(5);

        System.out.println("Circle Area = " + circle.area());
        System.out.println("Circle Perimeter = " + circle.perimeter());

        Rectangle rectangle = new Rectangle(10, 5);

        System.out.println("Rectangle Area = " + rectangle.area());
        System.out.println("Rectangle Perimeter = " + rectangle.perimeter());
    }
}