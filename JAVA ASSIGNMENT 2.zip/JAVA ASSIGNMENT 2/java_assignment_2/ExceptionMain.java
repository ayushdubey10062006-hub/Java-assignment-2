import java.util.Scanner;

public class ExceptionMain {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first number: ");
        int a = sc.nextInt();

        System.out.print("Enter second number: ");
        int b = sc.nextInt();

        // try-catch
        try {
            int result = a / b;
            System.out.println("Try-Catch Result = " + result);
        }
        catch (ArithmeticException e) {
            System.out.println("Try-Catch: Cannot divide by zero.");
        }

        // try-catch-finally
        try {
            int result = a / b;
            System.out.println("Try-Catch-Finally Result = " + result);
        }
        catch (ArithmeticException e) {
            System.out.println("Try-Catch-Finally: Cannot divide by zero.");
        }
        finally {
            System.out.println("Finally block always executes.");
        }

        sc.close();
    }
}
