import utilities.MathUtils;
public class Main{
    public static void main(String[] args) {
        MathUtils obj = new MathUtils();
        int result = obj.add(10,20);
        System.out.println("Sum = "+ result);


    }
}