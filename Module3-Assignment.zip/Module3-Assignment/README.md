# Module 3 Assignment – Threads, Synchronization, Locks, I/O & File Handling

Java solutions for the Module 3 assignment, covering multithreading,
synchronization, the `Lock` interface, byte/character I/O streams, file
handling, and a few `java.lang` / `java.util` / `java.util.regex` package
demos.

Each `.java` file is self-contained with its own `main` method, so every
program can be compiled and run on its own.

## Project structure

```
src/
├── thread_basics/
│   ├── EvenNumberThread.java          # Thread subclass, even 2–20, 500ms delay
│   ├── ReverseStringRunnable.java     # Runnable, reverses "MULTITHREADING"
│   ├── ThreadSleepExample.java        # "Thread 1" every 1s, "Thread 2" every 2s
│   ├── CountdownTickThread.java       # Countdown 10→1 + "Tick..." every 0.5s
│   ├── ThreadNamingPriority.java      # Worker-1/2/3 with different priorities
│   └── DaemonThreadExample.java       # Daemon auto-save thread + main file task
├── thread_synchronization/
│   ├── TicketBookingSystem.java       # synchronized method
│   ├── InventoryManagement.java       # synchronized block
│   ├── DiningPhilosophersDeadlock.java# intentional deadlock demo
│   ├── ProducerConsumerWaitNotify.java# wait()/notify() producer-consumer
│   ├── OddEvenWaitNotify.java         # alternating odd/even with wait/notify
│   └── StoppableDownload.java         # graceful thread stop via a flag
├── lock_interface/
│   ├── ReentrantLockCounter.java      # ReentrantLock vs. unsynchronized counter
│   └── DeadlockTryLockFix.java        # opposite-order locks fixed with tryLock()
├── io_streams/
│   ├── ReadFileByteStream.java        # FileInputStream
│   ├── WriteFileByteStream.java       # FileOutputStream
│   ├── ReadFileCharacterStream.java   # FileReader
│   ├── WriteFileCharacterStream.java  # FileWriter
│   └── BufferedIOExample.java         # BufferedReader / BufferedWriter
├── file_handling/
│   ├── FileExistenceCheck.java        # File.exists() / createNewFile()
│   ├── ListFilesInDirectory.java      # File.listFiles()
│   ├── CopyFile.java                  # byte-stream file copy
│   ├── DeleteFile.java                # File.delete()
│   └── RandomAccessFileExample.java   # RandomAccessFile seek/read/write
└── java_packages/
    ├── JavaLangDemo.java              # Math.random(), Math.abs(), Math.pow()
    ├── DateCalendarDemo.java          # java.util.Date and Calendar
    └── RegexEmailValidator.java       # Pattern/Matcher email validation
```

## Requirements

- JDK 11 or later (developed/tested against OpenJDK 21).

## Compiling and running

All classes use the package names shown above, so compile from the project
root and run with the fully-qualified class name.

```bash
# Compile everything into an "out" directory
javac -d out $(find src -name "*.java")

# Run any individual program, e.g.:
java -cp out thread_basics.EvenNumberThread
java -cp out thread_synchronization.TicketBookingSystem
java -cp out lock_interface.ReentrantLockCounter
java -cp out io_streams.WriteFileByteStream
java -cp out file_handling.ListFilesInDirectory
java -cp out java_packages.RegexEmailValidator
```

Or, from an IDE (IntelliJ, Eclipse, VS Code), just import the `src` folder
as a source root and run any class's `main` method directly.

### Notes on specific programs

- **`DiningPhilosophersDeadlock`** intentionally deadlocks — that's the
  point of the exercise. Run it to see both philosophers pick up one
  chopstick each and then hang forever; stop it with `Ctrl+C`.
  `DeadlockTryLockFix` shows the corresponding fix using `tryLock()` with a
  timeout.
- I/O and file-handling programs (`io_streams`, `file_handling`) read/write
  files in the current working directory (e.g. `input.txt`, `output.txt`,
  `example.txt`). Run the "write" example before the matching "read"
  example if the file doesn't already exist. Generated files are excluded
  via `.gitignore`.
- `ReentrantLockCounter` demonstrates the lost-update problem: the
  unsynchronized counter will often (not always) print a result lower than
  expected because of a data race, whereas the `ReentrantLock`-protected
  counter is always correct.
