package file_handling;

import java.io.File;
import java.io.IOException;

/**
 * Checks if a file exists in the system. If the file does not exist,
 * creates the file using the File class.
 */
public class FileExistenceCheck {

    public static void main(String[] args) {
        String fileName = "checkme.txt";
        File file = new File(fileName);

        if (file.exists()) {
            System.out.println("File '" + fileName + "' already exists.");
        } else {
            System.out.println("File '" + fileName + "' does not exist. Creating it...");
            try {
                boolean created = file.createNewFile();
                if (created) {
                    System.out.println("File '" + fileName + "' created successfully.");
                } else {
                    System.out.println("File could not be created (unexpected).");
                }
            } catch (IOException e) {
                System.out.println("Error creating file: " + e.getMessage());
            }
        }
    }
}
