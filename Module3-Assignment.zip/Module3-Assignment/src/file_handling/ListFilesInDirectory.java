package file_handling;

import java.io.File;
import java.util.Scanner;

/**
 * Lists all files in a directory specified by the user.
 * Handles exceptions/invalid input appropriately.
 */
public class ListFilesInDirectory {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter a directory path: ");
            String path = scanner.nextLine();

            File directory = new File(path);

            if (!directory.exists()) {
                System.out.println("Error: the path '" + path + "' does not exist.");
                return;
            }
            if (!directory.isDirectory()) {
                System.out.println("Error: '" + path + "' is not a directory.");
                return;
            }

            File[] files = directory.listFiles();
            if (files == null) {
                System.out.println("Error: unable to read directory contents "
                        + "(permission denied or I/O error).");
                return;
            }
            if (files.length == 0) {
                System.out.println("The directory is empty.");
                return;
            }

            System.out.println("Contents of '" + path + "':");
            for (File f : files) {
                String type = f.isDirectory() ? "[DIR] " : "[FILE]";
                System.out.println(type + " " + f.getName());
            }
        }
    }
}
