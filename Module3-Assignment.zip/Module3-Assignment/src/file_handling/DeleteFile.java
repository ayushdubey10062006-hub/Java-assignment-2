package file_handling;

import java.io.File;

/**
 * Deletes a file from the system using the File class.
 */
public class DeleteFile {

    public static void main(String[] args) {
        String fileName = "checkme.txt";
        File file = new File(fileName);

        if (!file.exists()) {
            System.out.println("File '" + fileName + "' does not exist; nothing to delete.");
            return;
        }

        boolean deleted = file.delete();
        if (deleted) {
            System.out.println("File '" + fileName + "' deleted successfully.");
        } else {
            System.out.println("Failed to delete file '" + fileName + "'.");
        }
    }
}
