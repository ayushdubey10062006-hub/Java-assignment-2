package file_handling;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Uses the RandomAccessFile class to read and write to specific positions
 * within a file. Writes some data at the beginning of the file, then
 * overwrites part of it later.
 */
public class RandomAccessFileExample {

    public static void main(String[] args) {
        String fileName = "random_access.txt";

        try (RandomAccessFile raf = new RandomAccessFile(fileName, "rw")) {
            // Start with an empty file.
            raf.setLength(0);

            // Write initial data at the beginning of the file.
            raf.seek(0);
            raf.writeBytes("Hello World! This is RandomAccessFile.");
            System.out.println("Initial write complete.");

            // Read back and print the full contents.
            raf.seek(0);
            printContents(raf);

            // Overwrite part of the file starting at position 6
            // ("Hello WORLD" -> replace "World!" with "Java!!").
            raf.seek(6);
            raf.writeBytes("Java!!");
            System.out.println("\nOverwrite complete.");

            // Read back and print the modified contents.
            raf.seek(0);
            printContents(raf);

        } catch (IOException e) {
            System.out.println("Error working with RandomAccessFile: " + e.getMessage());
        }
    }

    private static void printContents(RandomAccessFile raf) throws IOException {
        StringBuilder content = new StringBuilder();
        String line;
        raf.seek(0);
        byte[] buffer = new byte[(int) raf.length()];
        raf.readFully(buffer);
        content.append(new String(buffer));
        System.out.println("Current file contents: " + content);
    }
}
