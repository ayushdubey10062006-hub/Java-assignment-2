package file_handling;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Copies the contents of one file to another using byte streams
 * (FileInputStream and FileOutputStream).
 */
public class CopyFile {

    public static void main(String[] args) {
        String sourceFile = "source.txt";
        String destinationFile = "destination.txt";

        try (FileInputStream fis = new FileInputStream(sourceFile);
             FileOutputStream fos = new FileOutputStream(destinationFile)) {

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
            System.out.println("Copied '" + sourceFile + "' to '" + destinationFile + "' successfully.");

        } catch (IOException e) {
            System.out.println("Error copying file: " + e.getMessage()
                    + " (make sure '" + sourceFile + "' exists in the working directory)");
        }
    }
}
