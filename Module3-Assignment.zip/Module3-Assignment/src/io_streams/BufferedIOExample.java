package io_streams;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Modifies the FileReader / FileWriter examples to use BufferedReader and
 * BufferedWriter respectively, improving performance by reducing the
 * number of underlying I/O operations (reading/writing in larger chunks
 * and line-at-a-time instead of character-at-a-time).
 */
public class BufferedIOExample {

    public static void main(String[] args) {
        String fileName = "buffered_example.txt";

        writeWithBufferedWriter(fileName);
        readWithBufferedReader(fileName);
    }

    private static void writeWithBufferedWriter(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("This string was written using BufferedWriter.");
            writer.newLine();
            writer.write("Buffered I/O reduces the number of system calls.");
            writer.newLine();
            System.out.println("Wrote buffered content to '" + fileName + "'");
        } catch (IOException e) {
            System.out.println("Error writing file '" + fileName + "': " + e.getMessage());
        }
    }

    private static void readWithBufferedReader(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            System.out.println("File contents:");
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file '" + fileName + "': " + e.getMessage());
        }
    }
}
