package io_streams;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Writes a string into a file using FileOutputStream.
 * Writes "Java I/O Streams Example" to a file named output.txt.
 */
public class WriteFileByteStream {

    public static void main(String[] args) {
        String fileName = "output.txt";
        String data = "Java I/O Streams Example";

        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            fos.write(data.getBytes());
            System.out.println("Wrote to '" + fileName + "': " + data);
        } catch (IOException e) {
            System.out.println("Error writing file '" + fileName + "': " + e.getMessage());
        }
    }
}
