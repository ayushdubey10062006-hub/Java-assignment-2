package io_streams;

import java.io.FileReader;
import java.io.IOException;

/**
 * Reads a file using the FileReader class and prints the contents of the
 * file to the console. Run WriteFileCharacterStream first (or ensure
 * example.txt exists) so there is something to read.
 */
public class ReadFileCharacterStream {

    public static void main(String[] args) {
        String fileName = "example.txt";

        try (FileReader reader = new FileReader(fileName)) {
            int charData;
            StringBuilder content = new StringBuilder();
            while ((charData = reader.read()) != -1) {
                content.append((char) charData);
            }
            System.out.println("File contents:");
            System.out.println(content);
        } catch (IOException e) {
            System.out.println("Error reading file '" + fileName + "': " + e.getMessage());
        }
    }
}
