package io_streams;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Writes a string to a file using the FileWriter class.
 * The string is written to a file named example.txt.
 */
public class WriteFileCharacterStream {

    public static void main(String[] args) {
        String fileName = "example.txt";
        String data = "This string was written using FileWriter.";

        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(data);
            System.out.println("Wrote to '" + fileName + "': " + data);
        } catch (IOException e) {
            System.out.println("Error writing file '" + fileName + "': " + e.getMessage());
        }
    }
}
