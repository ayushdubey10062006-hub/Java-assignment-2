package io_streams;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * Reads a text file using FileInputStream and prints the contents to the
 * console. Run WriteFileByteStream first (or ensure input.txt exists) so
 * there is something to read.
 */
public class ReadFileByteStream {

    public static void main(String[] args) {
        String fileName = "input.txt";

        try (FileInputStream fis = new FileInputStream(fileName)) {
            int byteData;
            StringBuilder content = new StringBuilder();
            while ((byteData = fis.read()) != -1) {
                content.append((char) byteData);
            }
            System.out.println("File contents:");
            System.out.println(content);
        } catch (IOException e) {
            System.out.println("Error reading file '" + fileName + "': " + e.getMessage());
        }
    }
}
