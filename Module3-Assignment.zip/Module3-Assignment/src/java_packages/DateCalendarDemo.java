package java_packages;

import java.util.Calendar;
import java.util.Date;

/**
 * Uses the Date and Calendar classes to display the current date and time.
 *
 * Note: java.util.Date and java.util.Calendar are the legacy date/time API.
 * In modern Java, java.time (LocalDateTime, ZonedDateTime, etc.) is
 * preferred, but Date/Calendar are used here as requested.
 */
public class DateCalendarDemo {

    public static void main(String[] args) {
        // --- java.util.Date ---
        Date now = new Date();
        System.out.println("Current date/time (Date.toString()): " + now);

        // --- java.util.Calendar ---
        Calendar calendar = Calendar.getInstance();
        System.out.println("\nCurrent date/time (Calendar fields):");
        System.out.println("Year:   " + calendar.get(Calendar.YEAR));
        System.out.println("Month:  " + (calendar.get(Calendar.MONTH) + 1) // 0-based, so +1
                + " (Calendar.MONTH is zero-indexed)");
        System.out.println("Day:    " + calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println("Hour:   " + calendar.get(Calendar.HOUR_OF_DAY));
        System.out.println("Minute: " + calendar.get(Calendar.MINUTE));
        System.out.println("Second: " + calendar.get(Calendar.SECOND));

        // Calendar.getTime() converts back to a Date object.
        System.out.println("\nCalendar.getTime() as Date: " + calendar.getTime());
    }
}
