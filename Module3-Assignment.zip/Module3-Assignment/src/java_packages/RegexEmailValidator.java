package java_packages;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Uses the Pattern and Matcher classes from the java.util.regex package
 * to check if a given string is a valid email address.
 */
public class RegexEmailValidator {

    // A practical (not fully RFC-5322-complete) email pattern:
    // local-part@domain.tld
    private static final String EMAIL_REGEX =
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);

    public static boolean isValidEmail(String email) {
        if (email == null) {
            return false;
        }
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        return matcher.matches();
    }

    public static void main(String[] args) {
        String[] testEmails = {
                "user@example.com",
                "john.doe123@sub.domain.co.in",
                "invalid-email",
                "missing@dot",
                "@no-local-part.com",
                "spaces not@allowed.com",
                "name+tag@example.org"
        };

        for (String email : testEmails) {
            System.out.println(email + " -> " + (isValidEmail(email) ? "VALID" : "INVALID"));
        }
    }
}
