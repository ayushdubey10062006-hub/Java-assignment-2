package java_packages;

/**
 * Demonstrates the use of Math.random(), Math.abs(), and Math.pow()
 * from the java.lang package.
 */
public class JavaLangDemo {

    public static void main(String[] args) {
        // Math.random() returns a double in the range [0.0, 1.0)
        double randomValue = Math.random();
        System.out.println("Math.random(): " + randomValue);

        // Simulate a random dice roll (1-6) using Math.random()
        int diceRoll = (int) (Math.random() * 6) + 1;
        System.out.println("Simulated dice roll (1-6): " + diceRoll);

        // Math.abs() returns the absolute value
        int negativeNumber = -42;
        System.out.println("Math.abs(-42): " + Math.abs(negativeNumber));

        double negativeDouble = -3.14;
        System.out.println("Math.abs(-3.14): " + Math.abs(negativeDouble));

        // Math.pow() raises a number to a power
        double base = 2;
        double exponent = 10;
        System.out.println("Math.pow(2, 10): " + Math.pow(base, exponent));
        System.out.println("Math.pow(5, 3): " + Math.pow(5, 3));
    }
}
