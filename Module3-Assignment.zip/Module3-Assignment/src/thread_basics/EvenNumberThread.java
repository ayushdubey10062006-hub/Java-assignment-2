package thread_basics;

/**
 * Creates a thread by extending the Thread class.
 * Prints even numbers from 2 to 20 with a 500ms delay between each number.
 */
public class EvenNumberThread extends Thread {

    @Override
    public void run() {
        for (int i = 2; i <= 20; i += 2) {
            System.out.println(i);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Thread interrupted.");
                return;
            }
        }
    }

    public static void main(String[] args) {
        EvenNumberThread thread = new EvenNumberThread();
        thread.start();
    }
}
