package thread_basics;

/**
 * Creates two threads.
 * The first thread prints "Thread 1" every 1 second.
 * The second thread prints "Thread 2" every 2 seconds.
 */
public class ThreadSleepExample {

    public static void main(String[] args) {
        Thread thread1 = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                System.out.println("Thread 1");
                sleep(1000);
            }
        });

        Thread thread2 = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                System.out.println("Thread 2");
                sleep(2000);
            }
        });

        thread1.start();
        thread2.start();
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
