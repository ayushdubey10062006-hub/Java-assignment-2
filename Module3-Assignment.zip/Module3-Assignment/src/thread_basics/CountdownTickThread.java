package thread_basics;

/**
 * One thread prints a countdown from 10 to 1 with a 1-second delay,
 * while another thread simultaneously prints "Tick..." every half a second.
 */
public class CountdownTickThread {

    public static void main(String[] args) {
        Thread countdownThread = new Thread(() -> {
            for (int i = 10; i >= 1; i--) {
                System.out.println("Countdown: " + i);
                sleep(1000);
            }
            System.out.println("Countdown finished!");
        }, "Countdown-Thread");

        Thread tickThread = new Thread(() -> {
            while (true) {
                System.out.println("Tick...");
                sleep(500);
            }
        }, "Tick-Thread");
        tickThread.setDaemon(true); // stop ticking once the JVM has nothing else to do

        countdownThread.start();
        tickThread.start();

        try {
            countdownThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
