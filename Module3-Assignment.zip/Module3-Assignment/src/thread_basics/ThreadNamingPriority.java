package thread_basics;

/**
 * Creates three threads: "Worker-1", "Worker-2", and "Worker-3".
 * Assigns different priorities and prints messages from each thread
 * showing their execution order.
 *
 * Note: Thread priority is only a hint to the OS scheduler. The exact
 * execution order is not guaranteed, but higher-priority threads are
 * generally favored to run more often/sooner.
 */
public class ThreadNamingPriority {

    public static void main(String[] args) {
        Runnable task = () -> {
            Thread current = Thread.currentThread();
            for (int i = 1; i <= 5; i++) {
                System.out.println(current.getName() + " (priority " + current.getPriority()
                        + ") - iteration " + i);
            }
        };

        Thread worker1 = new Thread(task, "Worker-1");
        Thread worker2 = new Thread(task, "Worker-2");
        Thread worker3 = new Thread(task, "Worker-3");

        worker1.setPriority(Thread.MIN_PRIORITY);   // 1
        worker2.setPriority(Thread.NORM_PRIORITY);  // 5
        worker3.setPriority(Thread.MAX_PRIORITY);   // 10

        worker1.start();
        worker2.start();
        worker3.start();
    }
}
