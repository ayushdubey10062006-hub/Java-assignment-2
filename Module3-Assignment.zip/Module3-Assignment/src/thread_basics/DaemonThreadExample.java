package thread_basics;

/**
 * A daemon thread continuously writes "Auto-Save in progress..." every 3
 * seconds, while the main thread performs a (simulated) file processing task.
 * When the main thread finishes, the JVM exits and the daemon thread is
 * terminated automatically.
 */
public class DaemonThreadExample {

    public static void main(String[] args) {
        Thread autoSaveThread = new Thread(() -> {
            while (true) {
                System.out.println("Auto-Save in progress...");
                sleep(3000);
            }
        }, "AutoSave-Thread");

        autoSaveThread.setDaemon(true);
        autoSaveThread.start();

        // Simulate the main thread doing file processing work.
        for (int i = 1; i <= 5; i++) {
            System.out.println("Processing file chunk " + i + "...");
            sleep(2000);
        }

        System.out.println("File processing complete. Main thread exiting.");
        // The daemon thread is killed automatically once main() returns.
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
