package thread_basics;

/**
 * Creates a thread by implementing the Runnable interface.
 * Takes the string "MULTITHREADING" and prints its characters
 * in reverse order, one by one.
 */
public class ReverseStringRunnable implements Runnable {

    private final String input;

    public ReverseStringRunnable(String input) {
        this.input = input;
    }

    @Override
    public void run() {
        for (int i = input.length() - 1; i >= 0; i--) {
            System.out.println(input.charAt(i));
        }
    }

    public static void main(String[] args) {
        Thread thread = new Thread(new ReverseStringRunnable("MULTITHREADING"));
        thread.start();
    }
}
