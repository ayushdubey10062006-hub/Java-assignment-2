package lock_interface;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Two threads acquire two locks (lock1 and lock2) in opposite order, which
 * can cause a deadlock. This class demonstrates the fix: using tryLock()
 * with a timeout so a thread backs off, releases what it holds, and retries
 * instead of waiting forever.
 */
public class DeadlockTryLockFix {

    private static final Lock lock1 = new ReentrantLock();
    private static final Lock lock2 = new ReentrantLock();

    public static void main(String[] args) {
        Thread threadA = new Thread(() -> acquireLocksSafely("Thread-A", lock1, lock2));
        Thread threadB = new Thread(() -> acquireLocksSafely("Thread-B", lock2, lock1));

        threadA.start();
        threadB.start();
    }

    /**
     * Tries to acquire firstLock then secondLock, using a timeout on each
     * attempt. If it cannot get both within the timeout, it releases
     * whatever it holds and retries -- this avoids the deadlock that a plain
     * lock()/lock() call (in opposite order on the two threads) would cause.
     */
    private static void acquireLocksSafely(String name, Lock firstLock, Lock secondLock) {
        int attempts = 0;
        while (true) {
            attempts++;
            boolean gotFirst = false;
            boolean gotSecond = false;
            try {
                gotFirst = firstLock.tryLock(200, TimeUnit.MILLISECONDS);
                if (gotFirst) {
                    System.out.println(name + " acquired first lock (attempt " + attempts + ")");
                    // Small delay to increase the chance of contention for the demo.
                    Thread.sleep(50);
                    gotSecond = secondLock.tryLock(200, TimeUnit.MILLISECONDS);
                    if (gotSecond) {
                        System.out.println(name + " acquired second lock (attempt " + attempts + ")");
                        System.out.println(name + " is doing work with both locks...");
                        return; // success -- done, locks released in finally below
                    } else {
                        System.out.println(name + " could not get second lock, backing off...");
                    }
                } else {
                    System.out.println(name + " could not get first lock, backing off...");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } finally {
                if (gotSecond) secondLock.unlock();
                if (gotFirst) firstLock.unlock();
            }

            // Back off briefly before retrying, to reduce the chance of
            // repeatedly colliding with the other thread.
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
