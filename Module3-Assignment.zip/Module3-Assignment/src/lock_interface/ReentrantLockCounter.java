package lock_interface;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * A simple counter that can be safely incremented by multiple threads
 * using java.util.concurrent.locks.ReentrantLock. Compares the result
 * with an equivalent version that does not use a lock, to demonstrate
 * the lost-update problem that occurs without synchronization.
 */
public class ReentrantLockCounter {

    // ---- Safe counter using ReentrantLock ----
    static class LockedCounter {
        private int count = 0;
        private final Lock lock = new ReentrantLock();

        public void increment() {
            lock.lock();
            try {
                count++;
            } finally {
                lock.unlock(); // always release the lock, even if an exception occurs
            }
        }

        public int getCount() {
            return count;
        }
    }

    // ---- Unsafe counter with no synchronization at all ----
    static class UnsafeCounter {
        private int count = 0;

        public void increment() {
            count++; // NOT atomic: read-modify-write race condition
        }

        public int getCount() {
            return count;
        }
    }

    private static final int THREAD_COUNT = 10;
    private static final int INCREMENTS_PER_THREAD = 10_000;

    public static void main(String[] args) throws InterruptedException {
        LockedCounter lockedCounter = new LockedCounter();
        runIncrementThreads(lockedCounter::increment);
        System.out.println("Expected value:        " + (THREAD_COUNT * INCREMENTS_PER_THREAD));
        System.out.println("LockedCounter result:  " + lockedCounter.getCount()
                + " (always correct)");

        UnsafeCounter unsafeCounter = new UnsafeCounter();
        runIncrementThreads(unsafeCounter::increment);
        System.out.println("UnsafeCounter result:  " + unsafeCounter.getCount()
                + " (often lower than expected due to lost updates)");
    }

    private static void runIncrementThreads(Runnable incrementAction) throws InterruptedException {
        Thread[] threads = new Thread[THREAD_COUNT];
        for (int i = 0; i < THREAD_COUNT; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < INCREMENTS_PER_THREAD; j++) {
                    incrementAction.run();
                }
            });
        }
        for (Thread t : threads) t.start();
        for (Thread t : threads) t.join();
    }
}
