package thread_synchronization;

/**
 * Simulates a file download in a thread (printing "Downloading chunk X").
 * The download stops gracefully when a stop flag is set to false.
 */
public class StoppableDownload implements Runnable {

    // volatile so changes made by the main thread are visible to the
    // download thread immediately.
    private volatile boolean running = true;

    @Override
    public void run() {
        int chunk = 1;
        while (running) {
            System.out.println("Downloading chunk " + chunk);
            chunk++;
            try {
                Thread.sleep(400);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        System.out.println("Download stopped gracefully.");
    }

    public void stopDownload() {
        running = false;
    }

    public static void main(String[] args) throws InterruptedException {
        StoppableDownload download = new StoppableDownload();
        Thread downloadThread = new Thread(download, "Download-Thread");
        downloadThread.start();

        // Let it "download" for a while, then request a graceful stop.
        Thread.sleep(3000);
        System.out.println("Main thread: requesting stop...");
        download.stopDownload();

        downloadThread.join();
        System.out.println("Main thread: download thread has exited.");
    }
}
