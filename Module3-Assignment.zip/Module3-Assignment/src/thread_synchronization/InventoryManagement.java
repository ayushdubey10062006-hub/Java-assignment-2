package thread_synchronization;

/**
 * Multiple threads decrease the stock count of a product.
 * Uses a synchronized block (rather than a synchronized method) to ensure
 * stock updates are thread-safe.
 */
public class InventoryManagement {

    private int stock;
    private final Object lock = new Object();

    public InventoryManagement(int stock) {
        this.stock = stock;
    }

    public void decreaseStock(String threadName, int quantity) {
        synchronized (lock) {
            if (stock >= quantity) {
                stock -= quantity;
                System.out.println(threadName + " purchased " + quantity
                        + " unit(s). Stock remaining: " + stock);
            } else {
                System.out.println(threadName + " could not purchase " + quantity
                        + " unit(s). Insufficient stock (" + stock + " left).");
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        InventoryManagement inventory = new InventoryManagement(10);

        Runnable purchaseTask = () -> {
            String name = Thread.currentThread().getName();
            inventory.decreaseStock(name, 2);
        };

        Thread[] buyers = new Thread[6];
        for (int i = 0; i < buyers.length; i++) {
            buyers[i] = new Thread(purchaseTask, "Buyer-" + (i + 1));
        }
        for (Thread buyer : buyers) {
            buyer.start();
        }
        for (Thread buyer : buyers) {
            buyer.join();
        }

        System.out.println("Final stock: " + inventory.stock);
    }
}
