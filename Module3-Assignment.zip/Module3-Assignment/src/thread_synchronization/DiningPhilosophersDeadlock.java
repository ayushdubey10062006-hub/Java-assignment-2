package thread_synchronization;

/**
 * Simulates a simple Dining Philosophers problem where two philosophers try
 * to pick up chopsticks (resources) in opposite order, creating a deadlock.
 *
 * Philosopher A picks up chopstick1 then chopstick2.
 * Philosopher B picks up chopstick2 then chopstick1.
 * If both grab their first chopstick at the same time, neither can get the
 * second one and the program hangs (deadlock). Run this class to observe it;
 * it will print the first "picked up" messages and then hang, which is the
 * expected (and demonstrated) deadlock behavior.
 */
public class DiningPhilosophersDeadlock {

    private static final Object chopstick1 = new Object();
    private static final Object chopstick2 = new Object();

    public static void main(String[] args) {
        Thread philosopherA = new Thread(() -> {
            synchronized (chopstick1) {
                System.out.println("Philosopher A picked up chopstick 1");
                sleep(100); // give Philosopher B time to grab chopstick2
                synchronized (chopstick2) {
                    System.out.println("Philosopher A picked up chopstick 2");
                    System.out.println("Philosopher A is eating.");
                }
            }
        }, "Philosopher-A");

        Thread philosopherB = new Thread(() -> {
            synchronized (chopstick2) {
                System.out.println("Philosopher B picked up chopstick 2");
                sleep(100); // give Philosopher A time to grab chopstick1
                synchronized (chopstick1) {
                    System.out.println("Philosopher B picked up chopstick 1");
                    System.out.println("Philosopher B is eating.");
                }
            }
        }, "Philosopher-B");

        philosopherA.start();
        philosopherB.start();

        System.out.println("Main thread: if you don't see both philosophers eat, "
                + "this is the deadlock in action (each holds one chopstick and "
                + "waits forever for the other). See DeadlockTryLockFix for the fix.");
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
