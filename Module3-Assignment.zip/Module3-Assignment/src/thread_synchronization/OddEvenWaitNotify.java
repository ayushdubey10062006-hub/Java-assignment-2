package thread_synchronization;

/**
 * Two threads print numbers from 1 to 20 alternately: one prints odd
 * numbers, and the other prints even numbers. Uses wait() and notify()
 * for synchronization so the two threads take turns.
 */
public class OddEvenWaitNotify {

    private static final int MAX = 20;
    private int number = 1;
    private final Object lock = new Object();

    public void printOdd() {
        synchronized (lock) {
            while (number <= MAX) {
                while (number % 2 == 0) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                if (number > MAX) break;
                System.out.println("Odd: " + number);
                number++;
                lock.notify();
            }
        }
    }

    public void printEven() {
        synchronized (lock) {
            while (number <= MAX) {
                while (number % 2 != 0) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                if (number > MAX) break;
                System.out.println("Even: " + number);
                number++;
                lock.notify();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        OddEvenWaitNotify oddEven = new OddEvenWaitNotify();

        Thread oddThread = new Thread(oddEven::printOdd, "Odd-Thread");
        Thread evenThread = new Thread(oddEven::printEven, "Even-Thread");

        oddThread.start();
        evenThread.start();

        oddThread.join();
        evenThread.join();
    }
}
