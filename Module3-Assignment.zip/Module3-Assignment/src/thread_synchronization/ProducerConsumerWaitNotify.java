package thread_synchronization;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Implements a producer-consumer scenario where one thread (producer)
 * produces data and another thread (consumer) consumes it.
 * Uses wait() and notify() for synchronization.
 */
public class ProducerConsumerWaitNotify {

    private static final int CAPACITY = 5;
    private final Queue<Integer> buffer = new LinkedList<>();

    public void produce() throws InterruptedException {
        int value = 0;
        while (true) {
            synchronized (this) {
                while (buffer.size() == CAPACITY) {
                    wait(); // buffer full, wait for consumer
                }
                value++;
                buffer.add(value);
                System.out.println("Produced: " + value);
                notify(); // wake up the consumer
                Thread.sleep(300);
            }
        }
    }

    public void consume() throws InterruptedException {
        while (true) {
            synchronized (this) {
                while (buffer.isEmpty()) {
                    wait(); // buffer empty, wait for producer
                }
                int value = buffer.poll();
                System.out.println("Consumed: " + value);
                notify(); // wake up the producer
                Thread.sleep(500);
            }
        }
    }

    public static void main(String[] args) {
        ProducerConsumerWaitNotify pc = new ProducerConsumerWaitNotify();

        Thread producerThread = new Thread(() -> {
            try {
                pc.produce();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "Producer");

        Thread consumerThread = new Thread(() -> {
            try {
                pc.consume();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "Consumer");

        producerThread.setDaemon(true);
        consumerThread.setDaemon(true);
        producerThread.start();
        consumerThread.start();

        // Let the demo run for a few seconds, then stop the program.
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Demo finished.");
    }
}
