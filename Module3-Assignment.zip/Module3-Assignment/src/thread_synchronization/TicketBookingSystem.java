package thread_synchronization;

/**
 * A ticket booking system where multiple users (threads) attempt to book
 * tickets simultaneously. Uses a synchronized method to prevent overselling.
 */
public class TicketBookingSystem {

    private int availableTickets;

    public TicketBookingSystem(int availableTickets) {
        this.availableTickets = availableTickets;
    }

    // synchronized so only one thread can execute this method on this
    // instance at a time, preventing a race condition on availableTickets.
    public synchronized void bookTicket(String user) {
        if (availableTickets > 0) {
            availableTickets--;
            System.out.println(user + " booked a ticket. Remaining: " + availableTickets);
        } else {
            System.out.println(user + " failed to book a ticket. Sold out!");
        }
    }

    public static void main(String[] args) throws InterruptedException {
        TicketBookingSystem bookingSystem = new TicketBookingSystem(5);

        Runnable bookingTask = () -> bookingSystem.bookTicket(Thread.currentThread().getName());

        Thread[] users = new Thread[8];
        for (int i = 0; i < users.length; i++) {
            users[i] = new Thread(bookingTask, "User-" + (i + 1));
        }
        for (Thread user : users) {
            user.start();
        }
        for (Thread user : users) {
            user.join();
        }

        System.out.println("Booking session finished.");
    }
}
